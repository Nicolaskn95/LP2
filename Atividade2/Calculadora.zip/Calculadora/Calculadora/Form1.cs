﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            Double num;
            if (!Double.TryParse(textBox2.Text, out num))
                MessageBox.Show("Numero Invalido");
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            Double num;
            if (!Double.TryParse(textBox1.Text, out num))
                MessageBox.Show("Numero Invalido");
        }

        private void botao_soma_Click(object sender, EventArgs e)

        {
            double num1, num2, soma;

            if ((!Double.TryParse(textBox1.Text, out num1)) && (!Double.TryParse(textBox2.Text, out num2)))
            {
                MessageBox.Show("Numero Invalido 1 e 2");
                textBox1.Focus();
            }

            if (!Double.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Numero Invalido 1");
                textBox1.Focus();
            }
            else

            if (!Double.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("Numero Invalido 2");
                textBox2.Focus();
            }
            else
            {
                soma = num1 + num2;

                textBox3.Text = soma.ToString("N2");


            }
        }

        private void botao_menos_Click(object sender, EventArgs e)
        {
            double num1, num2, menos;

            if ((!Double.TryParse(textBox1.Text, out num1)) && (!Double.TryParse(textBox2.Text, out num2)))
            {
                MessageBox.Show("Numero Invalido 1 e 2");
                textBox1.Focus();
            }


            else
             if (!Double.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Numero Invalido 1");
                textBox1.Focus();
            }

            else
             if
            (!Double.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("Numero Invalido 2");
                textBox2.Focus();
            }

            else
            {
                menos = num1 - num2;

                textBox3.Text = menos.ToString("N2");


            }
        }

        private void botao_dividir_Click(object sender, EventArgs e)
        {
            double num1, num2, dividir;


            if ((!Double.TryParse(textBox1.Text, out num1)) && (!Double.TryParse(textBox2.Text, out num2)))
            {
                MessageBox.Show("Numero Invalido 1 e 2");
                textBox1.Focus();
            }

            if (!Double.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Numero Invalido 1");
                textBox1.Focus();
            }
            else

            if (!Double.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("Numero Invalido 2");
                textBox2.Focus();
            }
            else

            if (num2 == 0)
                MessageBox.Show("Não pode dividir por zero");

            else
            {
                dividir = num1 / num2;

                textBox3.Text = dividir.ToString();


            }
        }

        private void botao_vezes_Click(object sender, EventArgs e)
        {
            double num1, num2, vezes;

            if ((!Double.TryParse(textBox1.Text, out num1)) && (!Double.TryParse(textBox2.Text, out num2)))
            {
                MessageBox.Show("Numero Invalido 1 e 2");
                textBox1.Focus();
            }

            if (!Double.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Numero Invalido 1");
                textBox1.Focus();
            }
            else

            if (!Double.TryParse(textBox2.Text, out num2))
            {
                MessageBox.Show("Numero Invalido 2");
                textBox2.Focus();
            }
            else
            {
                vezes = num1 * num2;

                textBox3.Text = vezes.ToString("N2");


            }
        }
    }
}

