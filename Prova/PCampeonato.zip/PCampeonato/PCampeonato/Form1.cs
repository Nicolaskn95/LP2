﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int finalRA = 7;
            int[,] gols = new int[finalRA,3];
            string[] mensagem = new string[] { "Quantidade de gols feitos", "Quantidade de gols recebidos"};

            for(int x = 0; x < gols.GetLength(0); x++)
            {
                for (int y = 0; y < 2; y++)
                {
                    string infoGols = Interaction.InputBox(mensagem[y], "GOLS - Time "+ (x+1));
                    if (!int.TryParse(infoGols, out int qtdGols) || qtdGols < 0)
                    {
                        MessageBox.Show("Digite um número válido");
                        y--;
                    }
                    else
                    {
                        gols[x, y] = qtdGols;
                        if (y == 1)
                            gols[x, 2] = gols[x, 0] - gols[x, 1];
                    }
                }
            }
            int menorSaldo = 999999;
            int maiorsaldo = -999999;
            for(int z = 0; z < gols.GetLength(0); z++)
            {
                lstbxResultado.Items.Add("Time:" + (z + 1) + "  Gols feitos:" + gols[z,0] + "  Gols recebidos:" + gols[z,1] + "  Saldo de Gols:" + (gols[z,2]));
                if (gols[z,2] < menorSaldo)
                {
                    menorSaldo = gols[z, 2];
                }
                if (gols[z,2] > maiorsaldo)
                {
                    maiorsaldo = gols[z, 2];
                }
            }
            lstbxResultado.Items.Add("-------------------------------------");
            string pioresTimes = "";
            string melhoresTimes = "";
            for (int i = 0; i < gols.GetLength(0); i++)
            {
                if(gols[i, 2] == menorSaldo)
                {
                    pioresTimes = pioresTimes + "Time " + (i+1) + ",";
                }

                if (gols[i, 2] == maiorsaldo)
                {
                    melhoresTimes = melhoresTimes + "Time " + (i + 1) + ",";
                }
            }
            lstbxResultado.Items.Add("Pior(es) Time(s) :" + pioresTimes.Remove(pioresTimes.Length-1,1) + " Pior(es) Saldo(s) de Gols :" + menorSaldo.ToString());
            lstbxResultado.Items.Add("Melhor(es) Time(s) :" + melhoresTimes.Remove(melhoresTimes.Length-1,1) +  " Melhor(es) Saldo(s) de Gols:" + maiorsaldo.ToString());
        }
    }
}
