﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            int num1, num2;
            if (!int.TryParse(txtNumero2.Text, out num1))
            {
                MessageBox.Show("Digite um numero");
                return;
            }
            else if (!int.TryParse(txtNumero1.Text, out num2))
            {
                MessageBox.Show("Digite um numero");
                return;
            }

            if (num2 > num1)
            {
                MessageBox.Show("o numero no box 2 nao pode ser menor que o box 1");
                return;
            }
            else
            {
            int result;
            Random randomNum = new Random();
            result = randomNum.Next(num2, num1);

            MessageBox.Show(result.ToString());

           

            }


        }
    }
}
