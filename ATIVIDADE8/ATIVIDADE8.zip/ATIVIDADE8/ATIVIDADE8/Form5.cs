﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double A;
            int production;
            int B, C, D;
            double grossWage,bonus;

            if(!double.TryParse(txtSalary.Text, out A))
            {
                MessageBox.Show("Digite numeros(salario)");
                return;
            }

            if (!int.TryParse(txtProduction.Text, out production))
            {
                MessageBox.Show("Digite numeros(produção)");
                return;
            }

            if(!double.TryParse(txtBonus.Text, out bonus))
            {
                MessageBox.Show("Digite numeros(Gratificação)");
                return;
            }
                if(production >= 100)
                {
                    B = 1;
                }
                else
                {
                    B = 0;
                }

                if(production >= 120)
                {
                    C = 1;
                }
                else
                {
                    C = 0;
                }

                if(production >= 150)
                {
                    D = 1;
                }
                else
                {
                    D = 0;
                }
           
            grossWage = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + bonus;

            if (grossWage <= 7000 )
            {
                txtResultGrossWage.Text = grossWage.ToString("C2");
                
            }
            else if(grossWage > 7000 && bonus > 0 && production >= 150)
            {
                txtResultGrossWage.Text = grossWage.ToString("C2");
                
            }
            else
            {
                txtResultGrossWage.Text = "Não recerá seu salário sinto muito...";
            }
        }

        private void txtName_Validated(object sender, EventArgs e)
        {
            int numericValue;
            if (string.IsNullOrEmpty(txtName.Text))
            {
                MessageBox.Show("digite seu nome");
                txtName.Focus();
            }
            else
            {
                bool isNumber = int.TryParse(txtName.Text, out numericValue);
                if(isNumber == true)
                {
                    MessageBox.Show("Digite letras");
                    txtName.Focus();
                }

            }
        }
        private void txtRegistration_Validated(object sender, EventArgs e)
        {
            int matricul;
            if(!int.TryParse(txtRegistration.Text, out matricul))
            {
                MessageBox.Show("Digite numeros");
                txtRegistration.Focus();
            }
        }

        private void cbxFunction_Validated(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(cbxFunction.Text))
            {
                MessageBox.Show("Escolha o seu cargo");
                cbxFunction.Focus();
            }
        }
    }
}
