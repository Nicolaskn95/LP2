﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imcTrab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            double x;
            if (!double.TryParse(mskbxAltura.Text, out x))
            { 
                MessageBox.Show("Disgite sua altura");
                
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtClassificacao.Clear();
            txtIMC.Clear();
            txtObesidade.Clear();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            double x;
            if (!double.TryParse(mskbxPeso.Text, out x))
            {
                MessageBox.Show("Digite seu Peso");
                
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Double alt, peso, resultado;


            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Digite Peso return");
                mskbxPeso.Focus();
                return;
            }

            if (!double.TryParse(mskbxAltura.Text, out alt))
            {
                MessageBox.Show("Digite Altura return");
                mskbxAltura.Focus();
                return;
            }

            resultado = peso / Math.Pow(alt, 2);
            resultado = Math.Round(resultado, 1);
            txtIMC.Text = resultado.ToString();

            if(resultado <= 0 || resultado.ToString() == "NaN")
            {
            MessageBox.Show("Digite Altura e Peso");
                txtClassificacao.Clear();
                txtIMC.Clear();
                txtObesidade.Clear();
            }

            if (resultado < 18.5)
            { 
                txtClassificacao.Text = "MAGREZA";
                txtObesidade.Text = "0";
            }
            else 
                if(resultado < 24.9 )
            {
                txtClassificacao.Text = "NORMAL";
                txtObesidade.Text = "0";
            }
            else
                 if (resultado < 29.9)
            {
                txtClassificacao.Text = "SOBREPESO";
                txtObesidade.Text = "1";
            }
            else
                 if (resultado < 29.9)
            {
                txtClassificacao.Text = "OBESIDADE";
                txtObesidade.Text = "2";
            }
              else
            {
                txtClassificacao.Text = "OBESIDADE GRAVE";
                txtObesidade.Text = "3";
            }




        }
    }
}
