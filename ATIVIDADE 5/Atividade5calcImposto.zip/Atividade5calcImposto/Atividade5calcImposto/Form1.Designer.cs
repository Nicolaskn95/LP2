﻿
namespace Atividade5calcImposto
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblAliquotIRPF = new System.Windows.Forms.Label();
            this.lblALiquotINSS = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.btnVerifDesconto = new System.Windows.Forms.Button();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbxFemin = new System.Windows.Forms.RadioButton();
            this.rbtnMasc = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.mskbxNomeFunc = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquoINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalLiquid = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.cbxQtdeFilhos = new System.Windows.Forms.ComboBox();
            this.gbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(51, 43);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(160, 20);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome do Funcionário";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(524, 268);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(142, 20);
            this.lblDescINSS.TabIndex = 0;
            this.lblDescINSS.Text = "Desconto de INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(514, 329);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(141, 20);
            this.lblDescIRPF.TabIndex = 0;
            this.lblDescIRPF.Text = "Desconto de IRPF";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(268, 268);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(113, 20);
            this.lblSalLiquido.TabIndex = 0;
            this.lblSalLiquido.Text = "Salário Líquido";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(270, 328);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(112, 20);
            this.lblSalFamilia.TabIndex = 0;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblAliquotIRPF
            // 
            this.lblAliquotIRPF.AutoSize = true;
            this.lblAliquotIRPF.Location = new System.Drawing.Point(26, 329);
            this.lblAliquotIRPF.Name = "lblAliquotIRPF";
            this.lblAliquotIRPF.Size = new System.Drawing.Size(108, 20);
            this.lblAliquotIRPF.TabIndex = 0;
            this.lblAliquotIRPF.Text = "Aliquota IRPF";
            // 
            // lblALiquotINSS
            // 
            this.lblALiquotINSS.AutoSize = true;
            this.lblALiquotINSS.Location = new System.Drawing.Point(26, 268);
            this.lblALiquotINSS.Name = "lblALiquotINSS";
            this.lblALiquotINSS.Size = new System.Drawing.Size(109, 20);
            this.lblALiquotINSS.TabIndex = 0;
            this.lblALiquotINSS.Text = "Aliquota INSS";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(51, 92);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(101, 20);
            this.lblSalBruto.TabIndex = 0;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblDados
            // 
            this.lblDados.Location = new System.Drawing.Point(12, 187);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(72, 20);
            this.lblDados.TabIndex = 1;
            this.lblDados.Text = "lblDados";
            this.lblDados.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(51, 138);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(133, 20);
            this.lblNumFilhos.TabIndex = 0;
            this.lblNumFilhos.Text = "Número de Filhos";
            // 
            // btnVerifDesconto
            // 
            this.btnVerifDesconto.Location = new System.Drawing.Point(296, 386);
            this.btnVerifDesconto.Name = "btnVerifDesconto";
            this.btnVerifDesconto.Size = new System.Drawing.Size(168, 46);
            this.btnVerifDesconto.TabIndex = 1;
            this.btnVerifDesconto.Text = "Verificar Desconto";
            this.btnVerifDesconto.UseVisualStyleBackColor = true;
            this.btnVerifDesconto.Click += new System.EventHandler(this.btnVerifDesconto_Click);
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbxFemin);
            this.gbxSexo.Controls.Add(this.rbtnMasc);
            this.gbxSexo.Location = new System.Drawing.Point(572, 23);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(200, 100);
            this.gbxSexo.TabIndex = 2;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbxFemin
            // 
            this.rbxFemin.AutoSize = true;
            this.rbxFemin.Location = new System.Drawing.Point(62, 65);
            this.rbxFemin.Name = "rbxFemin";
            this.rbxFemin.Size = new System.Drawing.Size(92, 24);
            this.rbxFemin.TabIndex = 0;
            this.rbxFemin.Text = "Feminino";
            this.rbxFemin.UseVisualStyleBackColor = true;
            // 
            // rbtnMasc
            // 
            this.rbtnMasc.AutoSize = true;
            this.rbtnMasc.Checked = true;
            this.rbtnMasc.Location = new System.Drawing.Point(62, 20);
            this.rbtnMasc.Name = "rbtnMasc";
            this.rbtnMasc.Size = new System.Drawing.Size(98, 24);
            this.rbtnMasc.TabIndex = 0;
            this.rbtnMasc.TabStop = true;
            this.rbtnMasc.Text = "Masculino";
            this.rbtnMasc.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(57, 35);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(83, 24);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.TabStop = false;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.Location = new System.Drawing.Point(572, 138);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(200, 89);
            this.pnlCasado.TabIndex = 6;
            // 
            // mskbxNomeFunc
            // 
            this.mskbxNomeFunc.Location = new System.Drawing.Point(230, 40);
            this.mskbxNomeFunc.Name = "mskbxNomeFunc";
            this.mskbxNomeFunc.Size = new System.Drawing.Size(258, 26);
            this.mskbxNomeFunc.TabIndex = 2;
            this.mskbxNomeFunc.Validating += new System.ComponentModel.CancelEventHandler(this.mskbxNomeFunc_Validating);
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(230, 87);
            this.mskbxSalBruto.Mask = "99999.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(100, 26);
            this.mskbxSalBruto.TabIndex = 3;
            // 
            // mskbxAliquoINSS
            // 
            this.mskbxAliquoINSS.Enabled = false;
            this.mskbxAliquoINSS.Location = new System.Drawing.Point(140, 265);
            this.mskbxAliquoINSS.Name = "mskbxAliquoINSS";
            this.mskbxAliquoINSS.Size = new System.Drawing.Size(100, 26);
            this.mskbxAliquoINSS.TabIndex = 0;
            // 
            // mskbxAliquoIRPF
            // 
            this.mskbxAliquoIRPF.Enabled = false;
            this.mskbxAliquoIRPF.Location = new System.Drawing.Point(140, 325);
            this.mskbxAliquoIRPF.Name = "mskbxAliquoIRPF";
            this.mskbxAliquoIRPF.Size = new System.Drawing.Size(100, 26);
            this.mskbxAliquoIRPF.TabIndex = 0;
            // 
            // mskbxSalLiquid
            // 
            this.mskbxSalLiquid.Enabled = false;
            this.mskbxSalLiquid.Location = new System.Drawing.Point(388, 262);
            this.mskbxSalLiquid.Name = "mskbxSalLiquid";
            this.mskbxSalLiquid.Size = new System.Drawing.Size(100, 26);
            this.mskbxSalLiquid.TabIndex = 0;
            // 
            // mskbxSalFamilia
            // 
            this.mskbxSalFamilia.Enabled = false;
            this.mskbxSalFamilia.Location = new System.Drawing.Point(388, 325);
            this.mskbxSalFamilia.Name = "mskbxSalFamilia";
            this.mskbxSalFamilia.Size = new System.Drawing.Size(100, 26);
            this.mskbxSalFamilia.TabIndex = 0;
            // 
            // mskbxDescINSS
            // 
            this.mskbxDescINSS.Enabled = false;
            this.mskbxDescINSS.Location = new System.Drawing.Point(672, 262);
            this.mskbxDescINSS.Name = "mskbxDescINSS";
            this.mskbxDescINSS.Size = new System.Drawing.Size(100, 26);
            this.mskbxDescINSS.TabIndex = 0;
            // 
            // mskbxDescIRPF
            // 
            this.mskbxDescIRPF.Enabled = false;
            this.mskbxDescIRPF.Location = new System.Drawing.Point(672, 325);
            this.mskbxDescIRPF.Name = "mskbxDescIRPF";
            this.mskbxDescIRPF.Size = new System.Drawing.Size(100, 26);
            this.mskbxDescIRPF.TabIndex = 0;
            // 
            // cbxQtdeFilhos
            // 
            this.cbxQtdeFilhos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbxQtdeFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxQtdeFilhos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxQtdeFilhos.FormattingEnabled = true;
            this.cbxQtdeFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxQtdeFilhos.Location = new System.Drawing.Point(230, 130);
            this.cbxQtdeFilhos.MaxDropDownItems = 5;
            this.cbxQtdeFilhos.Name = "cbxQtdeFilhos";
            this.cbxQtdeFilhos.Size = new System.Drawing.Size(121, 28);
            this.cbxQtdeFilhos.TabIndex = 7;
            this.cbxQtdeFilhos.Tag = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.cbxQtdeFilhos);
            this.Controls.Add(this.mskbxDescIRPF);
            this.Controls.Add(this.mskbxDescINSS);
            this.Controls.Add(this.mskbxSalFamilia);
            this.Controls.Add(this.mskbxSalLiquid);
            this.Controls.Add(this.mskbxAliquoIRPF);
            this.Controls.Add(this.mskbxAliquoINSS);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.mskbxNomeFunc);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.btnVerifDesconto);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblALiquotINSS);
            this.Controls.Add(this.lblAliquotIRPF);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblNomeFunc);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblAliquotIRPF;
        private System.Windows.Forms.Label lblALiquotINSS;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Button btnVerifDesconto;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbxFemin;
        private System.Windows.Forms.RadioButton rbtnMasc;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.MaskedTextBox mskbxNomeFunc;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.MaskedTextBox mskbxAliquoINSS;
        private System.Windows.Forms.MaskedTextBox mskbxAliquoIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSalLiquid;
        private System.Windows.Forms.MaskedTextBox mskbxSalFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxDescINSS;
        private System.Windows.Forms.MaskedTextBox mskbxDescIRPF;
        private System.Windows.Forms.ComboBox cbxQtdeFilhos;
    }
}

